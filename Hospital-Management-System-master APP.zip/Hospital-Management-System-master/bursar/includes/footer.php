<div class="footer">
	<center>
		<h5 style="color:white;"> &copy; <?php echo date("Y"); ?> By Olti Asllanaj</h5>
	</center>
</div>

