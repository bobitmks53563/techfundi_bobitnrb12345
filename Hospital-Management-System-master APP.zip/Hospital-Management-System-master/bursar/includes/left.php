<div class="left"><br>
	<center>
	<b><br>
		<a href="index.php"><button class="btnlink">Home</button></a><br><br><br><br><br><br><br>
		<a href="reports.php"><button class="btnlink">Reports</button></a><br><br><br><br><br><br><br>
		<a href="settings.php"><button class="btnlink">Settings</button></a><br><br>
	</center>
				
</div>

