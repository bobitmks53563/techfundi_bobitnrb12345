#### Hospital-Management-System

This is a project that I created for my Database class in Fall 2016. I used PHP, MySQL for Back End and HTML and CSS for Front End.

I really enjoyed creating this project and wanted to share it with everybody.

© 2016  By Olti Asllanaj


