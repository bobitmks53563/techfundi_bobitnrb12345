<div class="left"><br>
	<center>
	<br>
		<a href="index.php"><button class="btnlink">Home</button></a><br><br><br><br><br><br><br>
		<a href="patients.php"><button class="btnlink">Patients</button></a><br><br><br><br><br><br><br>
		<a href="settings.php"><button class="btnlink">Settings</button></a><br><br>
	</center>
				
</div>