<?php 
require 'includes/users.php';
logout();
?>