<div class="header">
	<div class="headerleft">
		<b>Hospital Management System</b>
	</div>
	<div class="headerright">
		<b>
			<?php
			require '../includes/connect.php';
			require '../includes/users.php';
			laboratorydetails();
			 ?>
		</b>
	</div>
</div>

<html>
<head>
	<title>Hospital Management System - Login</title>
<html>
<head><title>Put Image in HTML</title>
</head>

<center>
<body background = "">

<img src = "laboratory2.jpg" width="1100px" height="450px"/>

</body></center>
</html>

<html>
	<style type="text/css">
	body
	{

		background-color: #1E90FF;
	}
		
	</style>
</head>
</html>